# My Text Utils

This is a simple Python library for extracting JSON objects from text strings.

## Installation

```bash
pip install .
